import React from 'react'
import Home from '../Home/Home'

const HomePage = () => {
  return (
    <Home></Home>
  )
}

export default HomePage
