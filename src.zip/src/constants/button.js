import LoadMore from '../assets/LoadMore.png'
import Button2 from '../assets/Button2.png'
export default{
    LoadMore,
    Button2
}