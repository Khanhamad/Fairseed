import Clock from '../assets/Clock.png'
import Threeuser from '../assets/Threeuser.png'
import FooterIconTw from '../assets/FooterIconTw.svg'
import FooterIconIn from '../assets/FooterIconIn.svg'
import FooterIconPi from '../assets/FooterIconPi.svg'
import FooterIconYo from '../assets/FooterIconYo.svg'


export default{
 Clock,
 Threeuser,
 FooterIconTw,
 FooterIconIn,
 FooterIconPi,
 FooterIconYo,
}