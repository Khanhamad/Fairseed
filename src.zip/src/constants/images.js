import SedalCheck from '../assets/SealCheck.png'
import Student from '../assets/Student.png'
import UsersThree from '../assets/UsersThree.png'
import HandCoins  from'../assets/HandCoins.png'
import HandShake from '../assets/Handshake.png'
import TextSeeAll from '../assets/TextSeeAll.png'
import Alarm from '../assets/Alarm.png'
import CaretRight from '../assets/CaretRight.png'
import Funnel from '../assets/Funnel.png'
import GenderFemale from '../assets/GenderFemale.png'
import Heart from '../assets/Heart.png'
import Megaphonesimple from '../assets/MegaphoneSimple.png'
import Mosque from '../assets/Mosque.png'
import TrendUp from '../assets/TrendUp.png'
import Filter from '../assets/Filter.png'
import Maskgroup from '../assets/Maskgroup.png'
import Tag from '../assets/Tag.png'
import Frame1 from '../assets/Frame1.png'
import range from '../assets/range.png'
import CardText from '../assets/CardText.png'
import Coins from '../assets/Coins.png'
import Maskgroup2 from '../assets/Maskgroup2.png'
import Frame2 from '../assets/Frame2.png'
import range2 from '../assets/range2.png'
import Maskgroup3 from '../assets/Maskgroup3.png'
import Frame3 from '../assets/Frame3.png'
import range3 from '../assets/range3.png'
import Maskgroup4 from '../assets/Maskgroup4.png'
import Frame4 from '../assets/Frame4.png'
import range4 from '../assets/range4.png'
import sliderimg from '../assets/sliderimg.png'
import HowItWork from '../assets/HowItWork.png'
import StepsTitle from '../assets/StepsTile.png'
import StepsTitle2 from '../assets/StepsTile2.png'
import StepsTitle3 from '../assets/StepsTile3.png'
import Arrow from '../assets/Arrow.png'
import Airlogo from '../assets/Airlogo.png'
import  Rectangle  from '../assets/Rectangle.png'
import Button3 from '../assets/Button3.png'
import Button4 from '../assets/Button4.png'
import LogoFooter from '../assets/LogoFooter.png'
import Logo from '../assets/Logo.png'
import HeroSection from '../assets/HeroSection.png'
import HeaderBgImg from '../assets/HeaderBgImg.png'
import one from '../assets/one.svg'
import two from '../assets/two.svg'
import three from '../assets/three.svg'
import person from '../assets/person.svg'
import pencicon from '../assets/pencicon.svg'
import Home from '../assets/Home.svg'
import FooterLogo from '../assets/FooterLogo.png'
import HeaderColor from '../assets/HeaderColor.svg'
import  RocketLaunch  from '../assets/RocketLaunch.png' 
import  coins2 from '../assets/Coins2.svg'
import  RocketLaunch2  from '../assets/RocketLaunch2.svg'
import ShareNetwork from '../assets/ShareNetwork.svg'
import share_Tabs from '../assets/share_Tabs.svg'
import account from '../assets/account.svg'
import caretDown from '../assets/caretDown.svg'
import NoData from '../assets/NoData.svg'
import ArrowBack from '../assets/ArrowBack .svg'
import UploadSimple from '../assets/UploadSimple.svg'
import UploadFile from '../assets/UploadFile.svg'



export default  {
    SedalCheck,
    Student,
    UsersThree,
    HandCoins,
    HandShake,
    TextSeeAll,
    Alarm,
    CaretRight,
    Funnel,
    GenderFemale,
    Heart,
    Megaphonesimple,
    Mosque,
    TrendUp,
    Filter,
    Maskgroup,
    Tag,
    Frame1,
    range,
    CardText,
    Coins,
    Maskgroup2,
    Frame2,
    range2,
    Maskgroup3,
    Frame3,
    range3,
    Maskgroup4,
    Frame4,
    range4,
    sliderimg,
    HowItWork,
    StepsTitle,
    StepsTitle2,
    StepsTitle3,
    Arrow,
    Airlogo,
    Rectangle,
    Button3,
    Button4,
    LogoFooter,
    Logo,
    HeroSection,
    HeaderBgImg,
    one,
    two,
    three,
    person,
    pencicon,
    Home,
    FooterLogo,
    HeaderColor,
    RocketLaunch,
    RocketLaunch2,
    coins2,
    ShareNetwork,
    account,
    caretDown,
    NoData,
    ArrowBack,
    UploadSimple,
    UploadFile

    
   
    



}